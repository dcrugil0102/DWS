<?php

final class productosControlador extends CControlador
{

	public array $menu = [];
	public array $menuizq = [];
	public array $barraUbi = [];
	public array $actual = [];

	public function __construct()
	{
		$this->menu = require __DIR__ . "/../config/menu.php";
		$this->menuizq = $this->menu['productos']['hijos'];

		session_start();
	}
	public function accionIndex()
	{
		$this->barraUbi = $this->menu;
		$this->actual = $this->menu["productos"];

		$producto = new Productos();

		$opciones = [];
		$filas = $producto->buscarTodos($opciones);

		foreach ($filas as $clave => $valor) {
			$filas[$clave]['fecha_alta'] = CGeneral::fechaMysqlANormal(
				$filas[$clave]["fecha_alta"]
			);
		}

		$cabecera = array(
			array("CAMPO" => "nombre", "ETIQUETA" => "Nombre"),
			array("CAMPO" => "descripcion_categoria", "ETIQUETA" => "Categoría"),
			array("CAMPO" => "fabricante", "ETIQUETA" => "Fabricante"),
			array("CAMPO" => "fecha_alta", "ETIQUETA" => "Fecha de alta"),
			array("CAMPO" => "unidades", "ETIQUETA" => "Unidades"),
			array("CAMPO" => "precio_base", "ETIQUETA" => "Precio base"),
			array("CAMPO" => "iva", "ETIQUETA" => "IVA (%)"),
			array("CAMPO" => "precio_iva", "ETIQUETA" => "Importe IVA"),
			array("CAMPO" => "precio_venta", "ETIQUETA" => "Precio final"),
			array("CAMPO" => "foto", "ETIQUETA" => "Foto"),
			array("CAMPO" => "borrado", "ETIQUETA" => "Borrado")
		);

		$this->dibujaVista(
			"indice",
			array(
				"filas" => $filas,
				"cabe" => $cabecera
			),
			"Lista de Productos"
		);
	}
}
