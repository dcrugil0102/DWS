<?php

$tabla = new CGrid(
    $cabe,
    $filas,
    array("class" => "tabla1")
);

echo $tabla->dibujate();
