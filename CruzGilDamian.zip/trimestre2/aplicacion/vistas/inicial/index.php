<?php
    echo "<br/>";

    echo "Hola mundo.";
    echo "<br/>";
    echo "<br/>".PHP_EOL;

    echo "funciona que no es poco";
    Sistema::app()->generaURL(["usuarios", "borrar"]);

    // echo CHTML::link("modificar usuario", Sistema::app()->generaURL(["usuarios", "modificar usuario"]);)
    
