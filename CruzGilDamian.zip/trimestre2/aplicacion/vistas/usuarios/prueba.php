<?php

echo "Esto es una pruebecilla";