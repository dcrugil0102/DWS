<?php
return [
    "inicial" => [
        "texto" => "Inicio",
        "enlace" => ["inicial", "index"],
        "hijos" => [
            "inicial" => [
                "texto" => "Inicio",
                "enlace" => ["inicial", "index"]
            ]
        ]
    ],
];
