<?php
header("Location: ./aplicacion/principal/index.php");
exit();
