<?php
interface IFabricante
{
    function metodoFabricacion();
    function metodoReciclado();
}
