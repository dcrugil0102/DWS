<?php

namespace VALNORMAL;

use \DateTime;

function validaEntero(int &$var, int $min, int $max, int $defecto): bool
{
    if (is_int($var) && $var >= $min && $var <= $max) {
        return true;
    } else {
        $var = $defecto;
        return false;
    }
}

function validaReal(float &$var, float $min, float $max, float $defecto): bool
{
    if (is_numeric($var) && $var >= $min && $var <= $max) {
        return true;
    } else {
        $var = $defecto;
        return false;
    }
}

function validaFecha(string &$var, string $defecto): bool
{
    $formato = "d/m/Y";
    $valida = DateTime::createFromFormat($formato, $var);

    $temp = explode("/", $var);
    $dia = (int)$temp[0];
    $mes = (int)$temp[1];
    $anio = (int)$temp[2];

    if ($valida && checkdate($mes, $dia, $anio)) {
        $var = $valida->format($formato);
        return true;
    } else {
        $var = $defecto;
        return false;
    }
}

function validaHora(string &$var, string $defecto): bool
{

    $partes = explode(":", $var);

    if (count($partes) === 3) {
        $hora = str_pad($partes[0], 2, '0', STR_PAD_LEFT);
        $minuto = str_pad($partes[1], 2, '0', STR_PAD_LEFT);
        $segundo = str_pad($partes[2], 2, '0', STR_PAD_LEFT);

        $var = "$hora:$minuto:$segundo";
    }

    $formato = "H:i:s";
    $valida = DateTime::createFromFormat($formato, $var);

    if ($valida) {
        $var = $valida->format($formato);
        return true;
    } else {
        $var = $defecto;
        return false;
    }
}


function validaEmail(string &$var, string $defecto): bool
{
    $patron = "/^[\w.-]+@[\w.-]+\.[a-zA-Z]{2,}$/";

    if (preg_match($patron, $var))
        return true;
    else {
        $var = $defecto;
        return false;
    }
}

function validaCadena(string &$var, int $longitud, string $defecto): bool
{
    if (strlen($var) > $longitud) {
        $var = $defecto;
        return false;
    } else
        return true;
}

function validaExpresion(string &$var, string $expresion, string $defecto): bool
{
    if (preg_match($expresion, $var)) {
        return true;
    } else {
        $var = $defecto;
        return false;
    }
}

function validaRango(mixed $var, array $posibles, int $tipo = 1): bool
{
    $sh = false;

    switch ($tipo) {
        case 1:
            foreach ($posibles as $key => $value) {
                if ($var === $value) {
                    $sh = true;
                }
            }
            break;
        case 2:
            foreach ($posibles as $key => $value) {
                if ($var === $key) {
                    $sh = true;
                }
            }
            break;
    }

    return $sh;
}
