<?php

$servidor = 'localhost';
$usuario = 'usu9';
$pass = 'usu9';
$baseDatos = 'practica9';
