<?php

echo "No seas malo y no entres en esta pagina";

?>

<img src="/../../../imagenes/chicotetactico.jpg" id="chicote">